var struct_files =
[
    [ "infile", "struct_files.html#a0f8cd54ad75acc7685d37e07aa690646", null ],
    [ "outfile", "struct_files.html#a3a45941eae23fbbcb6a707456d2d9067", null ]
];