var struct_event_list =
[
    [ "sim_time", "struct_event_list.html#ac506227baa9aeea32478d786f145cf8e", null ],
    [ "time_last_event", "struct_event_list.html#aa0f934f3cb50b7c70649ea3aa237134c", null ],
    [ "time_next_event", "struct_event_list.html#ab169e6e5e4a4d6bcd240bf06870ae197", null ]
];