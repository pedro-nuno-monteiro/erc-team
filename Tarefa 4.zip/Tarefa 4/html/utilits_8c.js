var utilits_8c =
[
    [ "ask_for_par", "utilits_8c.html#ab405294ee94d47aa1305e2236eb46eb9", null ],
    [ "ask_streams", "utilits_8c.html#a189ad95e30fe45bf8dbb37a1cfd4dd16", null ],
    [ "clear_screen", "utilits_8c.html#a4953d1edcbbfc7e420c423ded1d5621a", null ],
    [ "erlang_B", "utilits_8c.html#aa098088d930d230d2de01f141906b211", null ],
    [ "generate_other_streams", "utilits_8c.html#a507322543b0cef813fc88b4e03b2049f", null ],
    [ "receive_input_file", "utilits_8c.html#a36af62bcb16fd7489e40cb039e5ab1b9", null ]
];