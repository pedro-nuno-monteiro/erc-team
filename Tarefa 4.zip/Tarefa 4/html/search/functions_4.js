var searchData=
[
  ['freeq_0',['freeQ',['../circular__queue__dynamic_8c.html#a143faa746c3cf55e35769c6236de64ba',1,'freeQ(circular_queue *q):&#160;circular_queue_dynamic.c'],['../circular__queue__dynamic_8h.html#a143faa746c3cf55e35769c6236de64ba',1,'freeQ(circular_queue *q):&#160;circular_queue_dynamic.c']]]
];
