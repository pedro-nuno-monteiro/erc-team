var searchData=
[
  ['depart_0',['depart',['../fila1s_8c.html#aafe0dbd4a374555acaa0579c5508fde2',1,'depart(SystemState *state, Statistics *stats, EventList *events, circular_queue *q1):&#160;fila1s.c'],['../fila1s_8h.html#aafe0dbd4a374555acaa0579c5508fde2',1,'depart(SystemState *state, Statistics *stats, EventList *events, circular_queue *q1):&#160;fila1s.c']]],
  ['deq_1',['deQ',['../circular__queue__dynamic_8c.html#a6b61fcebbc3a978b92e14e5476a9be37',1,'deQ(circular_queue *q, float *val):&#160;circular_queue_dynamic.c'],['../circular__queue__dynamic_8h.html#a6b61fcebbc3a978b92e14e5476a9be37',1,'deQ(circular_queue *q, float *val):&#160;circular_queue_dynamic.c']]],
  ['dis_2',['dis',['../structcircular__queue.html#aa3f51980d1c007476cf766e34ab70300',1,'circular_queue']]],
  ['discipline_3',['discipline',['../circular__queue__dynamic_8h.html#a231c3a9524c4cace73486f8a08f0af22',1,'circular_queue_dynamic.h']]]
];
