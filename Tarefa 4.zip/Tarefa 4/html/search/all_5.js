var searchData=
[
  ['enq_0',['enQ',['../circular__queue__dynamic_8c.html#a4a89ababb6f306fd4f9e7f0e830ce1ab',1,'enQ(circular_queue *q, double val):&#160;circular_queue_dynamic.c'],['../circular__queue__dynamic_8h.html#a4a89ababb6f306fd4f9e7f0e830ce1ab',1,'enQ(circular_queue *q, double val):&#160;circular_queue_dynamic.c']]],
  ['erlang_5fb_1',['erlang_B',['../utilits_8c.html#aa098088d930d230d2de01f141906b211',1,'erlang_B(double A, unsigned int n):&#160;utilits.c'],['../utilits_8h.html#aa098088d930d230d2de01f141906b211',1,'erlang_B(double A, unsigned int n):&#160;utilits.c']]],
  ['eventlist_2',['EventList',['../struct_event_list.html',1,'']]],
  ['expand_3',['expand',['../circular__queue__dynamic_8c.html#a667c78f93cde065b49049a0f3cdcd312',1,'expand(circular_queue *q):&#160;circular_queue_dynamic.c'],['../circular__queue__dynamic_8h.html#a667c78f93cde065b49049a0f3cdcd312',1,'expand(circular_queue *q):&#160;circular_queue_dynamic.c']]],
  ['expon_4',['expon',['../fila1s_8c.html#ad3058f8628cdcdec85698cbf472abd86',1,'expon(float mean, int stream):&#160;fila1s.c'],['../fila1s_8h.html#ad3058f8628cdcdec85698cbf472abd86',1,'expon(float mean, int stream):&#160;fila1s.c']]]
];
