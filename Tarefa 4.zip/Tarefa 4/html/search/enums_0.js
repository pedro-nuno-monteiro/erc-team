var searchData=
[
  ['discipline_0',['discipline',['../circular__queue__dynamic_8h.html#a231c3a9524c4cace73486f8a08f0af22',1,'circular_queue_dynamic.h']]]
];
