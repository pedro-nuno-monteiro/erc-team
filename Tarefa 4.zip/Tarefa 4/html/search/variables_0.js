var searchData=
[
  ['a_0',['A',['../struct_system_state.html#a63aec5da9ded750541bdc6372ec8dabc',1,'SystemState']]],
  ['area_5fnum_5fin_5fq_1',['area_num_in_q',['../struct_statistics.html#a523abd66c2e61921dc1ed12cde9c2849',1,'Statistics']]],
  ['area_5fserver_5fstatus_2',['area_server_status',['../struct_statistics.html#a4de1fc91080af135284f3ced49072939',1,'Statistics']]]
];
