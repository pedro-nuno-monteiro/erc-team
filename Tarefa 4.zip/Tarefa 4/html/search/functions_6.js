var searchData=
[
  ['inic_0',['inic',['../circular__queue__dynamic_8c.html#a738310c8d153d56e77e33925a894dbc0',1,'inic(circular_queue *q, discipline dis):&#160;circular_queue_dynamic.c'],['../circular__queue__dynamic_8h.html#a738310c8d153d56e77e33925a894dbc0',1,'inic(circular_queue *q, discipline dis):&#160;circular_queue_dynamic.c']]],
  ['initialize_1',['initialize',['../fila1s_8c.html#ad93184aa61d7b96bacd2cdb916e717c4',1,'initialize(SystemState *state, Statistics *stats, EventList *events, int stream, circular_queue *q1):&#160;fila1s.c'],['../fila1s_8h.html#ad93184aa61d7b96bacd2cdb916e717c4',1,'initialize(SystemState *state, Statistics *stats, EventList *events, int stream, circular_queue *q1):&#160;fila1s.c']]],
  ['isempty_2',['isEmpty',['../circular__queue__dynamic_8c.html#a714025e7a7c2327c36ebe53c49c33a8e',1,'isEmpty(const circular_queue *q):&#160;circular_queue_dynamic.c'],['../circular__queue__dynamic_8h.html#a714025e7a7c2327c36ebe53c49c33a8e',1,'isEmpty(const circular_queue *q):&#160;circular_queue_dynamic.c']]],
  ['isfull_3',['isFull',['../circular__queue__dynamic_8c.html#a2cf2f29c3e6c90a4920547994b2e75c9',1,'isFull(const circular_queue *q):&#160;circular_queue_dynamic.c'],['../circular__queue__dynamic_8h.html#a2cf2f29c3e6c90a4920547994b2e75c9',1,'isFull(const circular_queue *q):&#160;circular_queue_dynamic.c']]]
];
