var searchData=
[
  ['infile_0',['infile',['../struct_files.html#a0f8cd54ad75acc7685d37e07aa690646',1,'Files']]]
];
