var searchData=
[
  ['printq_0',['printQ',['../circular__queue__dynamic_8c.html#af1f223cc6e5540e1438a760be7b84594',1,'printQ(const circular_queue *q):&#160;circular_queue_dynamic.c'],['../circular__queue__dynamic_8h.html#af1f223cc6e5540e1438a760be7b84594',1,'printQ(const circular_queue *q):&#160;circular_queue_dynamic.c']]]
];
