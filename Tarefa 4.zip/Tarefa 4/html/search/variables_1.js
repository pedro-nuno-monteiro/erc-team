var searchData=
[
  ['dis_0',['dis',['../structcircular__queue.html#aa3f51980d1c007476cf766e34ab70300',1,'circular_queue']]]
];
