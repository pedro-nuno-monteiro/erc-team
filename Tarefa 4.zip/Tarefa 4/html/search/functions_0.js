var searchData=
[
  ['arrive_0',['arrive',['../fila1s_8c.html#aed56b26f8a7a924f10f620a255de8702',1,'arrive(SystemState *state, Statistics *stats, Files *files, EventList *events, circular_queue *q1):&#160;fila1s.c'],['../fila1s_8h.html#aed56b26f8a7a924f10f620a255de8702',1,'arrive(SystemState *state, Statistics *stats, Files *files, EventList *events, circular_queue *q1):&#160;fila1s.c']]],
  ['ask_5ffor_5fpar_1',['ask_for_par',['../utilits_8c.html#ab405294ee94d47aa1305e2236eb46eb9',1,'ask_for_par(SystemState *state, Files *files, circular_queue *q):&#160;utilits.c'],['../utilits_8h.html#ab405294ee94d47aa1305e2236eb46eb9',1,'ask_for_par(SystemState *state, Files *files, circular_queue *q):&#160;utilits.c']]],
  ['ask_5fstreams_2',['ask_streams',['../utilits_8c.html#a189ad95e30fe45bf8dbb37a1cfd4dd16',1,'ask_streams(SystemState *state):&#160;utilits.c'],['../utilits_8h.html#a189ad95e30fe45bf8dbb37a1cfd4dd16',1,'ask_streams(SystemState *state):&#160;utilits.c']]]
];
