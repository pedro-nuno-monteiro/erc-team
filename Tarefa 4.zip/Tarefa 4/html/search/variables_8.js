var searchData=
[
  ['rear_0',['rear',['../structcircular__queue.html#a1885c4cf83f6a21e9fe1ea5150c1dfd7',1,'circular_queue']]]
];
