var searchData=
[
  ['lost_5fcustomers_0',['lost_customers',['../struct_statistics.html#a788947d17d9498f381a1f76a883aa82f',1,'Statistics']]]
];
