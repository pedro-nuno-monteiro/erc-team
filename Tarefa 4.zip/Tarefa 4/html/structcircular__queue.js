var structcircular__queue =
[
    [ "dis", "structcircular__queue.html#aa3f51980d1c007476cf766e34ab70300", null ],
    [ "front", "structcircular__queue.html#a733484a061857fac1845f1c377d2420c", null ],
    [ "max_size", "structcircular__queue.html#a4bc78610d90b692583951641b8f71318", null ],
    [ "rear", "structcircular__queue.html#a1885c4cf83f6a21e9fe1ea5150c1dfd7", null ],
    [ "tab", "structcircular__queue.html#a7f90c3eb2ec092cd43046a7928b6f630", null ]
];