var searchData=
[
  ['server_5fstatus_0',['server_status',['../struct_system_state.html#ae51b6ee2880318759d27443a74298fa9',1,'SystemState']]],
  ['sim_5ftime_1',['sim_time',['../struct_event_list.html#ac8b5e6092f9773f51cedaab4b136738d',1,'EventList']]],
  ['streams_2',['streams',['../struct_system_state.html#a73b27c3398aa1720f1f540c6ee765f87',1,'SystemState']]]
];
