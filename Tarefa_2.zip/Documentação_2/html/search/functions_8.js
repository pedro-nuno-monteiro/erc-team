var searchData=
[
  ['selectfreeserver_0',['selectFreeServer',['../fila1s_8c.html#a7d7e97d6c7e6924f105f98f9050d3e38',1,'selectFreeServer(SystemState *state, Statistics *stats):&#160;fila1s.c'],['../fila1s_8h.html#a7d7e97d6c7e6924f105f98f9050d3e38',1,'selectFreeServer(SystemState *state, Statistics *stats):&#160;fila1s.c']]]
];
