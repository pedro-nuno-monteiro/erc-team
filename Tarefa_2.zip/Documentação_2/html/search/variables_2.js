var searchData=
[
  ['lost_5fcustomers_0',['lost_customers',['../struct_statistics.html#acb661e710baf5da0ce33cee61d59ff96',1,'Statistics']]]
];
