var searchData=
[
  ['idle_0',['IDLE',['../fila1s_8h.html#a9c21a7caee326d7803b94ae1952b27ca',1,'fila1s.h']]],
  ['infile_1',['infile',['../struct_files.html#af19157da745ecb3f2b088c8f3a10c0a7',1,'Files']]],
  ['initialize_2',['initialize',['../fila1s_8c.html#a7fdc20bba0c0736ba207bd864343577b',1,'initialize(SystemState *state, Statistics *stats, EventList *events, int stream):&#160;fila1s.c'],['../fila1s_8h.html#a7fdc20bba0c0736ba207bd864343577b',1,'initialize(SystemState *state, Statistics *stats, EventList *events, int stream):&#160;fila1s.c']]]
];
