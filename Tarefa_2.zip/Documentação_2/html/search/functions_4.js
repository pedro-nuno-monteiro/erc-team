var searchData=
[
  ['initialize_0',['initialize',['../fila1s_8c.html#a7fdc20bba0c0736ba207bd864343577b',1,'initialize(SystemState *state, Statistics *stats, EventList *events, int stream):&#160;fila1s.c'],['../fila1s_8h.html#a7fdc20bba0c0736ba207bd864343577b',1,'initialize(SystemState *state, Statistics *stats, EventList *events, int stream):&#160;fila1s.c']]]
];
