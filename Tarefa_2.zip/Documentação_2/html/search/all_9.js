var searchData=
[
  ['next_5fevent_5ftype_0',['next_event_type',['../struct_system_state.html#a31cfa0a0a620cabbeeb83e640e64a4c6',1,'SystemState']]],
  ['num_5fcusts_5fdelayed_1',['num_custs_delayed',['../struct_system_state.html#a95b8a861931c663705d8ecedd6d0219c',1,'SystemState']]],
  ['num_5fdelays_5frequired_2',['num_delays_required',['../struct_system_state.html#ada13471633986449759bdd49f4ad8b87',1,'SystemState']]],
  ['num_5fevents_3',['num_events',['../struct_system_state.html#a2de2ffc34d0664f7a2e748d2342d1e10',1,'SystemState']]],
  ['num_5fin_5fq_4',['num_in_q',['../struct_system_state.html#a366819f3677736c863c5613d7d97bbe0',1,'SystemState']]],
  ['number_5fof_5fservers_5',['number_of_servers',['../struct_system_state.html#a338fcdd423201660ebe5bafe73ed6a60',1,'SystemState']]]
];
