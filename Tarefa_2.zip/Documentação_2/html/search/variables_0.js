var searchData=
[
  ['a_0',['A',['../struct_system_state.html#ad0fae016647bf6b083c331ca152b50e1',1,'SystemState']]],
  ['area_5fnum_5fin_5fq_1',['area_num_in_q',['../struct_statistics.html#a2f4a1bbeb237a5f133e7e991ee240593',1,'Statistics']]],
  ['area_5fserver_5fstatus_2',['area_server_status',['../struct_statistics.html#ae558c2f029d0e9c95913daaae7aa0033',1,'Statistics']]]
];
