var searchData=
[
  ['area_5fnum_5fin_5fq_0',['area_num_in_q',['../struct_statistics.html#a523abd66c2e61921dc1ed12cde9c2849',1,'Statistics']]],
  ['area_5fserver_5fstatus_1',['area_server_status',['../struct_statistics.html#aabebc1c6539c0793cbfdbc7dfb83c98a',1,'Statistics']]]
];
