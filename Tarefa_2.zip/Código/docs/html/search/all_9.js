var searchData=
[
  ['next_5fevent_5ftype_0',['next_event_type',['../struct_system_state.html#a025f28d80c11afd5971044d352106ff3',1,'SystemState']]],
  ['num_5fcusts_5fdelayed_1',['num_custs_delayed',['../struct_system_state.html#a0d8eb29d06f62f8fbbcae5e354d6605f',1,'SystemState']]],
  ['num_5fdelays_5frequired_2',['num_delays_required',['../struct_system_state.html#aacdf5a975cc7ab7bca8033966a3aad7a',1,'SystemState']]],
  ['num_5fin_5fq_3',['num_in_q',['../struct_system_state.html#a3cce96c89ccad01b99b1af3c8304a642',1,'SystemState']]]
];
