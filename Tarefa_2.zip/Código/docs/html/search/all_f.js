var searchData=
[
  ['update_5ftime_5favg_5fstats_0',['update_time_avg_stats',['../fila1s_8c.html#a4bfec20f8a953e28b389800b506499f4',1,'update_time_avg_stats(SystemState *state, Statistics *stats, EventList *events):&#160;fila1s.c'],['../fila1s_8h.html#a4bfec20f8a953e28b389800b506499f4',1,'update_time_avg_stats(SystemState *state, Statistics *stats, EventList *events):&#160;fila1s.c']]]
];
