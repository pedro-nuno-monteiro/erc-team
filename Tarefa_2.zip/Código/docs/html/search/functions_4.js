var searchData=
[
  ['lcgrand_0',['lcgrand',['../lcgrand_8c.html#ab7a029a34172d39dfb6a0d42b16d819a',1,'lcgrand(int stream):&#160;lcgrand.c'],['../lcgrand_8h.html#ab7a029a34172d39dfb6a0d42b16d819a',1,'lcgrand(int stream):&#160;lcgrand.c']]],
  ['lcgrandgt_1',['lcgrandgt',['../lcgrand_8c.html#a55603bb2a14add3004878c9ef7da2ee0',1,'lcgrandgt(int stream):&#160;lcgrand.c'],['../lcgrand_8h.html#a55603bb2a14add3004878c9ef7da2ee0',1,'lcgrandgt(int stream):&#160;lcgrand.c']]],
  ['lcgrandst_2',['lcgrandst',['../lcgrand_8c.html#a5753b4a68dc9d72527a66bb460c0251c',1,'lcgrandst(long zset, int stream):&#160;lcgrand.c'],['../lcgrand_8h.html#a5753b4a68dc9d72527a66bb460c0251c',1,'lcgrandst(long zset, int stream):&#160;lcgrand.c']]]
];
