var searchData=
[
  ['front_0',['front',['../structcircular__queue.html#a733484a061857fac1845f1c377d2420c',1,'circular_queue']]]
];
