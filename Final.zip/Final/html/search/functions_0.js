var searchData=
[
  ['arrive_0',['arrive',['../fila1s_8c.html#a07ab452a88ce70d315b1956099284c7f',1,'arrive(SystemState *state, Statistics *stats, Files *files, EventList *events, circular_queue *q1, InitialValues *init):&#160;fila1s.c'],['../fila1s_8h.html#a07ab452a88ce70d315b1956099284c7f',1,'arrive(SystemState *state, Statistics *stats, Files *files, EventList *events, circular_queue *q1, InitialValues *init):&#160;fila1s.c']]],
  ['ask_5ffor_5fpar_1',['ask_for_par',['../utilits_8c.html#a58c168ea01f4b41e88755b8e892b9c7a',1,'ask_for_par(Files *files, circular_queue *q, InitialValues *init):&#160;utilits.c'],['../utilits_8h.html#a58c168ea01f4b41e88755b8e892b9c7a',1,'ask_for_par(Files *files, circular_queue *q, InitialValues *init):&#160;utilits.c']]],
  ['ask_5fstreams_2',['ask_streams',['../utilits_8c.html#af248c572553ddbab2b31ca8a78c4d6e0',1,'ask_streams(InitialValues *init):&#160;utilits.c'],['../utilits_8h.html#af248c572553ddbab2b31ca8a78c4d6e0',1,'ask_streams(InitialValues *init):&#160;utilits.c']]]
];
