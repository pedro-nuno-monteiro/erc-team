var searchData=
[
  ['server_5fstatus_0',['server_status',['../struct_system_state.html#a3350faea7a0d68ccf60582320b0f9daa',1,'SystemState']]],
  ['sim_5ftime_1',['sim_time',['../struct_event_list.html#ac506227baa9aeea32478d786f145cf8e',1,'EventList']]],
  ['streams_2',['streams',['../struct_initial_values.html#a2ec5c57f073577a94a58ba761e6ff274',1,'InitialValues']]]
];
