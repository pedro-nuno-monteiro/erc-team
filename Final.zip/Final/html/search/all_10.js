var searchData=
[
  ['tab_0',['tab',['../structcircular__queue.html#a7f90c3eb2ec092cd43046a7928b6f630',1,'circular_queue']]],
  ['task_20final_1',['Task final',['../index.html',1,'']]],
  ['time_5farrival_2',['time_arrival',['../struct_system_state.html#a43e8196ec93012b42546e6a3646ef1e4',1,'SystemState']]],
  ['time_5flast_5fevent_3',['time_last_event',['../struct_event_list.html#aa0f934f3cb50b7c70649ea3aa237134c',1,'EventList']]],
  ['time_5fnext_5fevent_4',['time_next_event',['../struct_event_list.html#ab169e6e5e4a4d6bcd240bf06870ae197',1,'EventList']]],
  ['timing_5',['timing',['../fila1s_8c.html#a251b70b2f3fa49e0ef6b5096c1d4270b',1,'timing(SystemState *state, Statistics *stats, Files *files, EventList *events):&#160;fila1s.c'],['../fila1s_8h.html#a251b70b2f3fa49e0ef6b5096c1d4270b',1,'timing(SystemState *state, Statistics *stats, Files *files, EventList *events):&#160;fila1s.c']]],
  ['total_5fof_5fdelays_6',['total_of_delays',['../struct_statistics.html#a571491c6c5cc8b325f989bbefdf07bd4',1,'Statistics']]]
];
