var searchData=
[
  ['real_5fnumber_5fof_5fcostumers_5fchegados_0',['real_number_of_costumers_chegados',['../struct_statistics.html#ab83d82c7d59216da22d427507b3a62ab',1,'Statistics']]],
  ['real_5fnumber_5fof_5fcostumers_5fpartidos_1',['real_number_of_costumers_partidos',['../struct_statistics.html#add1c7b500284d8f8604abba16734b7e6',1,'Statistics']]],
  ['rear_2',['rear',['../structcircular__queue.html#a1885c4cf83f6a21e9fe1ea5150c1dfd7',1,'circular_queue']]],
  ['run_5fstreams_3',['run_streams',['../struct_system_state.html#a90d81eb92b0df0174e23f0d407aad33e',1,'SystemState']]]
];
