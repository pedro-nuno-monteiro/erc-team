var searchData=
[
  ['a_0',['A',['../struct_initial_values.html#ae0d43edf3bdace37cdd0f920a1c879a9',1,'InitialValues']]],
  ['area_5fnum_5fin_5fq_1',['area_num_in_q',['../struct_statistics.html#a523abd66c2e61921dc1ed12cde9c2849',1,'Statistics']]],
  ['area_5fserver_5fstatus_2',['area_server_status',['../struct_statistics.html#a4de1fc91080af135284f3ced49072939',1,'Statistics']]]
];
