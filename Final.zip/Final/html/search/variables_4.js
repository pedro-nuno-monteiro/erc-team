var searchData=
[
  ['lost_5fcostumers_0',['lost_costumers',['../struct_statistics.html#adee6805e5262468f56fdb9454b650f5f',1,'Statistics']]]
];
