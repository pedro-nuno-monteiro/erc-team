var searchData=
[
  ['statistics_0',['Statistics',['../struct_statistics.html',1,'']]],
  ['systemstate_1',['SystemState',['../struct_system_state.html',1,'']]]
];
