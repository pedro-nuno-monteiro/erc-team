var struct_statistics =
[
    [ "area_num_in_q", "struct_statistics.html#a523abd66c2e61921dc1ed12cde9c2849", null ],
    [ "area_server_status", "struct_statistics.html#a4de1fc91080af135284f3ced49072939", null ],
    [ "lost_costumers", "struct_statistics.html#adee6805e5262468f56fdb9454b650f5f", null ],
    [ "num_occupied_servers", "struct_statistics.html#a3fd5833129482f7f0afc5d831ae0fbb7", null ],
    [ "real_number_of_costumers_chegados", "struct_statistics.html#ab83d82c7d59216da22d427507b3a62ab", null ],
    [ "real_number_of_costumers_partidos", "struct_statistics.html#add1c7b500284d8f8604abba16734b7e6", null ],
    [ "total_of_delays", "struct_statistics.html#a571491c6c5cc8b325f989bbefdf07bd4", null ],
    [ "waiting_costumers", "struct_statistics.html#a433c2a5d3fc5a8c34e2a59155f296cf5", null ]
];