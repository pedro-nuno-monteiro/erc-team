var dir_45008a02622db185b1e526a297913d22 =
[
    [ "circular_queue_dynamic.c", "circular__queue__dynamic_8c.html", "circular__queue__dynamic_8c" ],
    [ "circular_queue_dynamic.h", "circular__queue__dynamic_8h.html", "circular__queue__dynamic_8h" ],
    [ "fila1s.c", "fila1s_8c.html", "fila1s_8c" ],
    [ "fila1s.h", "fila1s_8h.html", "fila1s_8h" ],
    [ "lcgrand.c", "lcgrand_8c.html", "lcgrand_8c" ],
    [ "lcgrand.h", "lcgrand_8h.html", "lcgrand_8h" ],
    [ "simula_fila1s.c", "simula__fila1s_8c.html", "simula__fila1s_8c" ],
    [ "utilits.c", "utilits_8c.html", "utilits_8c" ],
    [ "utilits.h", "utilits_8h.html", "utilits_8h" ]
];