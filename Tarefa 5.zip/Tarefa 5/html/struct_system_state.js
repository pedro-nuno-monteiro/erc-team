var struct_system_state =
[
    [ "next_event_type", "struct_system_state.html#a025f28d80c11afd5971044d352106ff3", null ],
    [ "num_custs_delayed", "struct_system_state.html#a0d8eb29d06f62f8fbbcae5e354d6605f", null ],
    [ "num_delays_required_state", "struct_system_state.html#a2069ccd905dbe50db7d3a68a41550ee5", null ],
    [ "num_events", "struct_system_state.html#a08627fb3e85fcd93cf364fa34a4befcd", null ],
    [ "num_in_q", "struct_system_state.html#a3cce96c89ccad01b99b1af3c8304a642", null ],
    [ "run_streams", "struct_system_state.html#a90d81eb92b0df0174e23f0d407aad33e", null ],
    [ "server_status", "struct_system_state.html#a3350faea7a0d68ccf60582320b0f9daa", null ],
    [ "time_arrival", "struct_system_state.html#a43e8196ec93012b42546e6a3646ef1e4", null ]
];