var annotated_dup =
[
    [ "circular_queue", "structcircular__queue.html", "structcircular__queue" ],
    [ "EventList", "struct_event_list.html", "struct_event_list" ],
    [ "Files", "struct_files.html", "struct_files" ],
    [ "InitialValues", "struct_initial_values.html", "struct_initial_values" ],
    [ "Statistics", "struct_statistics.html", "struct_statistics" ],
    [ "SystemState", "struct_system_state.html", "struct_system_state" ]
];