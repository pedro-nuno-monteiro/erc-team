var searchData=
[
  ['circular_5fqueue_0',['circular_queue',['../structcircular__queue.html',1,'']]]
];
