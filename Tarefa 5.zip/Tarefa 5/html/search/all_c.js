var searchData=
[
  ['outfile_0',['outfile',['../struct_files.html#a3a45941eae23fbbcb6a707456d2d9067',1,'Files']]]
];
