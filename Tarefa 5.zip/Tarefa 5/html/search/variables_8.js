var searchData=
[
  ['real_5fnumber_5fof_5fcustumers_5fchegados_0',['real_number_of_custumers_chegados',['../struct_statistics.html#adb57218db019e54ea05ff8e719fc5763',1,'Statistics']]],
  ['rear_1',['rear',['../structcircular__queue.html#a1885c4cf83f6a21e9fe1ea5150c1dfd7',1,'circular_queue']]],
  ['run_5fstreams_2',['run_streams',['../struct_system_state.html#a90d81eb92b0df0174e23f0d407aad33e',1,'SystemState']]]
];
