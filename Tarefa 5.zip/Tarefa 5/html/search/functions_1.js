var searchData=
[
  ['clear_5fscreen_0',['clear_screen',['../utilits_8c.html#a4953d1edcbbfc7e420c423ded1d5621a',1,'clear_screen():&#160;utilits.c'],['../utilits_8h.html#a4953d1edcbbfc7e420c423ded1d5621a',1,'clear_screen():&#160;utilits.c']]]
];
