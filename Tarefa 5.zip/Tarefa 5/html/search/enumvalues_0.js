var searchData=
[
  ['fifo_0',['FIFO',['../circular__queue__dynamic_8h.html#a231c3a9524c4cace73486f8a08f0af22a7795ebef271efe70b28f37deb9a07a83',1,'circular_queue_dynamic.h']]]
];
