var searchData=
[
  ['waiting_5fcustumers_0',['waiting_custumers',['../struct_statistics.html#a494eeb22a3fac5e2ea88948942950ed7',1,'Statistics']]],
  ['without_5finfinite_5fqueue_1',['without_infinite_queue',['../struct_initial_values.html#ab8b1fe7bd001c6e589b8fb1955aa8717',1,'InitialValues']]]
];
