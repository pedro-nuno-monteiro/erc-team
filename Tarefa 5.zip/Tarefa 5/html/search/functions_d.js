var searchData=
[
  ['update_5ftime_5favg_5fstats_0',['update_time_avg_stats',['../fila1s_8c.html#aa6f5c5478db756cc957fe7f590b6d59c',1,'update_time_avg_stats(SystemState *state, Statistics *stats, EventList *events, InitialValues *init):&#160;fila1s.c'],['../fila1s_8h.html#aa6f5c5478db756cc957fe7f590b6d59c',1,'update_time_avg_stats(SystemState *state, Statistics *stats, EventList *events, InitialValues *init):&#160;fila1s.c']]]
];
