var searchData=
[
  ['circular_5fqueue_5fdynamic_2ec_0',['circular_queue_dynamic.c',['../circular__queue__dynamic_8c.html',1,'']]],
  ['circular_5fqueue_5fdynamic_2eh_1',['circular_queue_dynamic.h',['../circular__queue__dynamic_8h.html',1,'']]]
];
