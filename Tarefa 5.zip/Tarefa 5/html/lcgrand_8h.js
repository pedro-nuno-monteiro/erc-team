var lcgrand_8h =
[
    [ "MODLUS", "lcgrand_8h.html#a025dad112e1cca745a8a40fcf497bb60", null ],
    [ "MULT1", "lcgrand_8h.html#a3d46a92418aceea1a9b012a680596149", null ],
    [ "MULT2", "lcgrand_8h.html#acfbf81ed58e555d0fe2db899f3ad89ac", null ],
    [ "lcgrand", "lcgrand_8h.html#ab7a029a34172d39dfb6a0d42b16d819a", null ],
    [ "lcgrandgt", "lcgrand_8h.html#a55603bb2a14add3004878c9ef7da2ee0", null ],
    [ "lcgrandst", "lcgrand_8h.html#a5753b4a68dc9d72527a66bb460c0251c", null ]
];