var circular__queue__dynamic_8h =
[
    [ "circular_queue", "structcircular__queue.html", "structcircular__queue" ],
    [ "discipline", "circular__queue__dynamic_8h.html#a231c3a9524c4cace73486f8a08f0af22", [
      [ "FIFO", "circular__queue__dynamic_8h.html#a231c3a9524c4cace73486f8a08f0af22a7795ebef271efe70b28f37deb9a07a83", null ],
      [ "LIFO", "circular__queue__dynamic_8h.html#a231c3a9524c4cace73486f8a08f0af22aa01d7974609bd0111390748dc20f1633", null ]
    ] ],
    [ "deQ", "circular__queue__dynamic_8h.html#a6b61fcebbc3a978b92e14e5476a9be37", null ],
    [ "enQ", "circular__queue__dynamic_8h.html#a4a89ababb6f306fd4f9e7f0e830ce1ab", null ],
    [ "expand", "circular__queue__dynamic_8h.html#a667c78f93cde065b49049a0f3cdcd312", null ],
    [ "freeQ", "circular__queue__dynamic_8h.html#a143faa746c3cf55e35769c6236de64ba", null ],
    [ "inic", "circular__queue__dynamic_8h.html#a738310c8d153d56e77e33925a894dbc0", null ],
    [ "isEmpty", "circular__queue__dynamic_8h.html#a714025e7a7c2327c36ebe53c49c33a8e", null ],
    [ "isFull", "circular__queue__dynamic_8h.html#a2cf2f29c3e6c90a4920547994b2e75c9", null ],
    [ "printQ", "circular__queue__dynamic_8h.html#af1f223cc6e5540e1438a760be7b84594", null ]
];