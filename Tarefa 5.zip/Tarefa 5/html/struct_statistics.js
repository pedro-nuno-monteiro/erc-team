var struct_statistics =
[
    [ "area_num_in_q", "struct_statistics.html#a523abd66c2e61921dc1ed12cde9c2849", null ],
    [ "area_server_status", "struct_statistics.html#a4de1fc91080af135284f3ced49072939", null ],
    [ "lost_customers", "struct_statistics.html#a788947d17d9498f381a1f76a883aa82f", null ],
    [ "num_occupied_servers", "struct_statistics.html#a3fd5833129482f7f0afc5d831ae0fbb7", null ],
    [ "real_number_of_custumers_chegados", "struct_statistics.html#adb57218db019e54ea05ff8e719fc5763", null ],
    [ "total_of_delays", "struct_statistics.html#a571491c6c5cc8b325f989bbefdf07bd4", null ],
    [ "waiting_custumers", "struct_statistics.html#a494eeb22a3fac5e2ea88948942950ed7", null ]
];