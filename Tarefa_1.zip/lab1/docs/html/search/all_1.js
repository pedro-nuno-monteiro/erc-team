var searchData=
[
  ['area_5fnum_5fin_5fq_0',['area_num_in_q',['../struct_statistics.html#a523abd66c2e61921dc1ed12cde9c2849',1,'Statistics']]],
  ['area_5fserver_5fstatus_1',['area_server_status',['../struct_statistics.html#aabebc1c6539c0793cbfdbc7dfb83c98a',1,'Statistics']]],
  ['arrive_2',['arrive',['../fila1s_8c.html#a0162b1e4ed03e2abbfc30ad29467e1e7',1,'arrive(SystemState *state, Statistics *stats, Files *files, EventList *events):&#160;fila1s.c'],['../fila1s_8h.html#a0162b1e4ed03e2abbfc30ad29467e1e7',1,'arrive(SystemState *state, Statistics *stats, Files *files, EventList *events):&#160;fila1s.c']]]
];
