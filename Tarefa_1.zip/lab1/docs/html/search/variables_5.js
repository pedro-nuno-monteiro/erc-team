var searchData=
[
  ['server_5fstatus_0',['server_status',['../struct_system_state.html#a8b9bde20528c6005e9d88be71f353850',1,'SystemState']]],
  ['sim_5ftime_1',['sim_time',['../struct_event_list.html#ac506227baa9aeea32478d786f145cf8e',1,'EventList']]]
];
