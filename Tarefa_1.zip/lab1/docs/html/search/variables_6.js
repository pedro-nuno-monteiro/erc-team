var searchData=
[
  ['time_5farrival_0',['time_arrival',['../struct_system_state.html#a43e8196ec93012b42546e6a3646ef1e4',1,'SystemState']]],
  ['time_5flast_5fevent_1',['time_last_event',['../struct_event_list.html#aa0f934f3cb50b7c70649ea3aa237134c',1,'EventList']]],
  ['time_5fnext_5fevent_2',['time_next_event',['../struct_event_list.html#ac914b8d4b2e29f1ed0df030236a80b0d',1,'EventList']]],
  ['total_5fof_5fdelays_3',['total_of_delays',['../struct_statistics.html#a571491c6c5cc8b325f989bbefdf07bd4',1,'Statistics']]]
];
