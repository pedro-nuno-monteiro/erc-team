var searchData=
[
  ['initialize_0',['initialize',['../fila1s_8c.html#a2ee5ed153d410f043fdaf6a3fa3611c9',1,'initialize(SystemState *state, Statistics *stats, EventList *events):&#160;fila1s.c'],['../fila1s_8h.html#a2ee5ed153d410f043fdaf6a3fa3611c9',1,'initialize(SystemState *state, Statistics *stats, EventList *events):&#160;fila1s.c']]]
];
