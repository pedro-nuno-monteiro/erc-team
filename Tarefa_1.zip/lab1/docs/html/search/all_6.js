var searchData=
[
  ['idle_0',['IDLE',['../fila1s_8h.html#a9c21a7caee326d7803b94ae1952b27ca',1,'fila1s.h']]],
  ['infile_1',['infile',['../struct_files.html#a0f8cd54ad75acc7685d37e07aa690646',1,'Files']]],
  ['initialize_2',['initialize',['../fila1s_8c.html#a2ee5ed153d410f043fdaf6a3fa3611c9',1,'initialize(SystemState *state, Statistics *stats, EventList *events):&#160;fila1s.c'],['../fila1s_8h.html#a2ee5ed153d410f043fdaf6a3fa3611c9',1,'initialize(SystemState *state, Statistics *stats, EventList *events):&#160;fila1s.c']]]
];
