var searchData=
[
  ['server_5fstatus_0',['server_status',['../struct_system_state.html#a8b9bde20528c6005e9d88be71f353850',1,'SystemState']]],
  ['sim_5ftime_1',['sim_time',['../struct_event_list.html#ac506227baa9aeea32478d786f145cf8e',1,'EventList']]],
  ['simula_5ffila1s_2ec_2',['simula_fila1s.c',['../simula__fila1s_8c.html',1,'']]],
  ['statistics_3',['Statistics',['../struct_statistics.html',1,'']]],
  ['systemstate_4',['SystemState',['../struct_system_state.html',1,'']]]
];
