var searchData=
[
  ['time_5farrival_0',['time_arrival',['../struct_system_state.html#a43e8196ec93012b42546e6a3646ef1e4',1,'SystemState']]],
  ['time_5flast_5fevent_1',['time_last_event',['../struct_event_list.html#aa0f934f3cb50b7c70649ea3aa237134c',1,'EventList']]],
  ['time_5fnext_5fevent_2',['time_next_event',['../struct_event_list.html#ac914b8d4b2e29f1ed0df030236a80b0d',1,'EventList']]],
  ['timing_3',['timing',['../fila1s_8c.html#af9613f3aac7c14ce50fae88142a9f479',1,'timing(SystemState *state, Statistics *stats, Files *files, EventList *events, int num_events):&#160;fila1s.c'],['../fila1s_8h.html#af9613f3aac7c14ce50fae88142a9f479',1,'timing(SystemState *state, Statistics *stats, Files *files, EventList *events, int num_events):&#160;fila1s.c']]],
  ['total_5fof_5fdelays_4',['total_of_delays',['../struct_statistics.html#a571491c6c5cc8b325f989bbefdf07bd4',1,'Statistics']]]
];
