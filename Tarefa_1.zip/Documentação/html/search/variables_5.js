var searchData=
[
  ['server_5fstatus_0',['server_status',['../struct_system_state.html#a88b7daa22ba44a5a1f6b9102f148a924',1,'SystemState']]],
  ['sim_5ftime_1',['sim_time',['../struct_event_list.html#ac8b5e6092f9773f51cedaab4b136738d',1,'EventList']]]
];
