var searchData=
[
  ['depart_0',['depart',['../fila1s_8c.html#a286e95bc21d5188cf69dafd3bfd784a0',1,'depart(SystemState *state, Statistics *stats, EventList *events, int stream):&#160;fila1s.c'],['../fila1s_8h.html#a286e95bc21d5188cf69dafd3bfd784a0',1,'depart(SystemState *state, Statistics *stats, EventList *events, int stream):&#160;fila1s.c']]],
  ['documentação_20simula_20fila_1',['Documentação Simula Fila',['../index.html',1,'']]]
];
