var searchData=
[
  ['infile_0',['infile',['../struct_files.html#af19157da745ecb3f2b088c8f3a10c0a7',1,'Files']]]
];
