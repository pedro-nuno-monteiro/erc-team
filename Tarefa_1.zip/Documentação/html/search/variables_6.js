var searchData=
[
  ['time_5farrival_0',['time_arrival',['../struct_system_state.html#af50c29f0b99eccfc8c3aa905f1d73cc2',1,'SystemState']]],
  ['time_5flast_5fevent_1',['time_last_event',['../struct_event_list.html#afaba36fb5a44b654432472baa454e7a9',1,'EventList']]],
  ['time_5fnext_5fevent_2',['time_next_event',['../struct_event_list.html#a91e19de9007dd487ea383c6c302667b4',1,'EventList']]],
  ['total_5fof_5fdelays_3',['total_of_delays',['../struct_statistics.html#a4c8e9207a46d30f1ab90d90bc2242733',1,'Statistics']]]
];
