var searchData=
[
  ['outfile_0',['outfile',['../struct_files.html#ae581849c67336453bd5b81e6518019a9',1,'Files']]]
];
