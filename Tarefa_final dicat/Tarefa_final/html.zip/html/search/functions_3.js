var searchData=
[
  ['initialize_0',['initialize',['../fila1s_8c.html#a3f19a1dd769a96fa5a3d767be200d514',1,'fila1s.c']]]
];
