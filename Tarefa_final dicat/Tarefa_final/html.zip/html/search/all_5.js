var searchData=
[
  ['idle_0',['IDLE',['../fila1s_8c.html#a9c21a7caee326d7803b94ae1952b27ca',1,'fila1s.c']]],
  ['initialize_1',['initialize',['../fila1s_8c.html#a3f19a1dd769a96fa5a3d767be200d514',1,'fila1s.c']]]
];
