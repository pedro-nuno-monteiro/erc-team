var searchData=
[
  ['server_5fstatus_0',['server_status',['../structvariaveis.html#a88b7daa22ba44a5a1f6b9102f148a924',1,'variaveis']]],
  ['sim_5ftime_1',['sim_time',['../structvariaveis.html#ac8b5e6092f9773f51cedaab4b136738d',1,'variaveis']]]
];
