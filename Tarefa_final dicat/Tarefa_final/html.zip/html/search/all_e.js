var searchData=
[
  ['variaveis_0',['variaveis',['../structvariaveis.html',1,'']]]
];
