var searchData=
[
  ['time_5farrival_0',['time_arrival',['../structvariaveis.html#af50c29f0b99eccfc8c3aa905f1d73cc2',1,'variaveis']]],
  ['time_5flast_5fevent_1',['time_last_event',['../structvariaveis.html#afaba36fb5a44b654432472baa454e7a9',1,'variaveis']]],
  ['time_5fnext_5fevent_2',['time_next_event',['../structvariaveis.html#a91e19de9007dd487ea383c6c302667b4',1,'variaveis']]],
  ['timing_3',['timing',['../fila1s_8c.html#acadf08d339ee7e0955bdeaa5098da592',1,'fila1s.c']]],
  ['total_5fof_5fdelays_4',['total_of_delays',['../structvariaveis.html#a4c8e9207a46d30f1ab90d90bc2242733',1,'variaveis']]]
];
