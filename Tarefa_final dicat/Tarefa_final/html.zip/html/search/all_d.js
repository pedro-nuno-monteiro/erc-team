var searchData=
[
  ['update_5ftime_5favg_5fstats_0',['update_time_avg_stats',['../fila1s_8c.html#ade235e80b17d359e644631ab21e15071',1,'fila1s.c']]]
];
