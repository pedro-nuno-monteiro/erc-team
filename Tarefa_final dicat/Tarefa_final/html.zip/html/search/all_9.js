var searchData=
[
  ['q_5flimit_0',['Q_LIMIT',['../fila1s_8c.html#aaa75be566c9c8da967954407ca97c72b',1,'fila1s.c']]]
];
