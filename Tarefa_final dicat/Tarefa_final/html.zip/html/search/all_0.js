var searchData=
[
  ['area_5fnum_5fin_5fq_0',['area_num_in_q',['../structvariaveis.html#a2f4a1bbeb237a5f133e7e991ee240593',1,'variaveis']]],
  ['area_5fserver_5fstatus_1',['area_server_status',['../structvariaveis.html#ae2601bd8168b927b6e6beb7c708f5290',1,'variaveis']]],
  ['arrive_2',['arrive',['../fila1s_8c.html#a637f6703dedfed2b663088481f77bece',1,'fila1s.c']]]
];
